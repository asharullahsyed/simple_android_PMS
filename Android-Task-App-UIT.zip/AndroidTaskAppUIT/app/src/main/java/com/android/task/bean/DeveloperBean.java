package com.android.task.bean;

public class DeveloperBean {

	private int developer_id;
	private String developer_firstname;
	private String developer_lastname;
	private String developer_mobilenumber;
	private String developer_address;
	private String developer_username;
	private String developer_password;
	public int getDeveloper_id() {
		return developer_id;
	}
	public void setDeveloper_id(int developer_id) {
		this.developer_id = developer_id;
	}
	public String getDeveloper_firstname() {
		return developer_firstname;
	}
	public void setDeveloper_firstname(String developer_firstname) {
		this.developer_firstname = developer_firstname;
	}
	public String getDeveloper_lastname() {
		return developer_lastname;
	}
	public void setDeveloper_lastname(String developer_lastname) {
		this.developer_lastname = developer_lastname;
	}
	public String getDeveloper_mobilenumber() {
		return developer_mobilenumber;
	}
	public void setDeveloper_mobilenumber(String developer_mobilenumber) {
		this.developer_mobilenumber = developer_mobilenumber;
	}
	public String getDeveloper_address() {
		return developer_address;
	}
	public void setDeveloper_address(String developer_address) {
		this.developer_address = developer_address;
	}
	public String getDeveloper_username() {
		return developer_username;
	}
	public void setDeveloper_username(String developer_username) {
		this.developer_username = developer_username;
	}
	public String getDeveloper_password() {
		return developer_password;
	}
	public void setDeveloper_password(String developer_password) {
		this.developer_password = developer_password;
	}

}
