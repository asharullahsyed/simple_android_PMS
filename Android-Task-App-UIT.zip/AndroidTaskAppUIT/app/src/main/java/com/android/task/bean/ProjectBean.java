package com.android.task.bean;

public class ProjectBean {

	private int project_id;
	private String project_name;
	private String project_description;
	private String project_mobilenumber;
	private String project_address;
	private String project_department;
	private String project_class;

	public int getProject_id() {
		return project_id;
	}

	public void setProject_id(int project_id) {
		this.project_id = project_id;
	}

	public String getProject_name() {
		return project_name;
	}

	public void setProject_name(String project_name) {
		this.project_name = project_name;
	}

	public String getProject_description() {
		return project_description;
	}

	public void setProject_description(String project_description) {
		this.project_description = project_description;
	}

	public String getProject_mobilenumber() {
		return project_mobilenumber;
	}

	public void setProject_mobilenumber(String project_mobilenumber) {
		this.project_mobilenumber = project_mobilenumber;
	}

	public String getProject_address() {
		return project_address;
	}

	public void setProject_address(String project_address) {
		this.project_address = project_address;
	}

	public String getProject_department() {
		return project_department;
	}

	public void setProject_department(String project_department) {
		this.project_department = project_department;
	}

	public String getProject_class() {
		return project_class;
	}

	public void setProject_class(String project_class) {
		this.project_class = project_class;
	}

}















//package com.android.task.bean;
//
//public class ProjectBean {
//
//	private int project_id;
//	private String project_firstname;
//	private String project_lastname;
//	private String project_mobilenumber;
//	private String project_address;
//	private String project_department;
//	private String project_class;
//	public int getProject_id() {
//		return project_id;
//	}
//	public void setProject_id(int project_id) {
//		this.project_id = project_id;
//	}
//	public String getProject_firstname() {
//		return project_firstname;
//	}
//	public void setProject_firstname(String project_firstname) {
//		this.project_firstname = project_firstname;
//	}
//	public String getProject_lastname() {
//		return project_lastname;
//	}
//	public void setProject_lastname(String project_lastname) {
//		this.project_lastname = project_lastname;
//	}
//	public String getProject_mobilenumber() {
//		return project_mobilenumber;
//	}
//	public void setProject_mobilenumber(String project_mobilenumber) {
//		this.project_mobilenumber = project_mobilenumber;
//	}
//	public String getProject_address() {
//		return project_address;
//	}
//	public void setProject_address(String project_address) {
//		this.project_address = project_address;
//	}
//	public String getProject_department() {
//		return project_department;
//	}
//	public void setProject_department(String project_department) {
//		this.project_department = project_department;
//	}
//	public String getProject_class() {
//		return project_class;
//	}
//	public void setProject_class(String project_class) {
//		this.project_class = project_class;
//	}
//
//}
