package com.android.task.bean;

public class TaskSessionBean {

	private int task_session_id;
	private int task_session_developer_id;
	private String task_session_department;
	private String task_session_class;
	private String task_session_date;
	private String task_session_subject;

	public int getTask_session_id() {
		return task_session_id;
	}
	public void setTask_session_id(int task_session_id) {
		this.task_session_id = task_session_id;
	}
	public int getTask_session_developer_id() {
		return task_session_developer_id;
	}
	public void setTask_session_developer_id(int task_session_developer_id) {
		this.task_session_developer_id = task_session_developer_id;
	}
	public String getTask_session_department() {
		return task_session_department;
	}
	public void setTask_session_department(
			String task_session_department) {
		this.task_session_department = task_session_department;
	}
	public String getTask_session_class() {
		return task_session_class;
	}
	public void setTask_session_class(String task_session_class) {
		this.task_session_class = task_session_class;
	}
	public String getTask_session_date() {
		return task_session_date;
	}
	public void setTask_session_date(String task_session_date) {
		this.task_session_date = task_session_date;
	}
	public String getTask_session_subject() {
		return task_session_subject;
	}
	public void setTask_session_subject(String task_session_subject) {
		this.task_session_subject = task_session_subject;
	}
}
