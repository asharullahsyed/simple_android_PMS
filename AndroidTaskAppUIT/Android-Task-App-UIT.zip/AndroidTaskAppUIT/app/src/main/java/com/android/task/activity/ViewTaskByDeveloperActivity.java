package com.android.task.activity;

import java.util.ArrayList;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.android.task.bean.TaskBean;
import com.android.task.bean.DeveloperBean;
import com.android.task.bean.ProjectBean;
import com.android.task.context.ApplicationContext;
import com.android.task.db.DBAdapter;
import com.example.androidtasksystem.R;

public class ViewTaskByDeveloperActivity extends Activity {

	ArrayList<TaskBean> taskBeanList;
	private ListView listView;
	private ArrayAdapter<String> listAdapter;

	DBAdapter dbAdapter = new DBAdapter(this);

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.__listview_main);

		listView = (ListView) findViewById(R.id.listview);
		final ArrayList<String> taskList = new ArrayList<String>();
		taskList.add("Id | ProjectName | Status");

		taskBeanList = ((ApplicationContext) ViewTaskByDeveloperActivity.this.getApplicationContext()).getTaskBeanList();

		for (TaskBean taskBean : taskBeanList) {
			String users = "";
			if (taskBean.getTask_session_id() != 0) {
				DBAdapter dbAdapter = new DBAdapter(ViewTaskByDeveloperActivity.this);
				ProjectBean projectBean = dbAdapter.getProjectById(taskBean.getTask_project_id());
				users = taskBean.getTask_project_id() + ". " + projectBean.getProject_name() + "," + projectBean.getProject_description() + " " + taskBean.getTask_status();
			} else {
				users = taskBean.getTask_status();
			}

			taskList.add(users);
			Log.d("users: ", users);
		}

		listAdapter = new ArrayAdapter<String>(this, R.layout.view_task_list, R.id.labelTask, taskList);
		listView.setAdapter(listAdapter);

        /*listView.setOnItemLongClickListener(new OnItemLongClickListener() {

            @Override
            public boolean onItemLongClick(AdapterView<?> arg0, View arg1,
                    final int position, long arg3) {

                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(ViewTaskByDeveloperActivity.this);

                alertDialogBuilder.setTitle(getTitle()+"decision");
                alertDialogBuilder.setMessage("Are you sure?");

                alertDialogBuilder.setPositiveButton("Yes",new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,int id) {

                        developerList.remove(position);
                        listAdapter.notifyDataSetChanged();
                        listAdapter.notifyDataSetInvalidated();

                        dbAdapter.deleteDeveloper(developerBeanList.get(position).getDeveloper_id());
                        developerBeanList = dbAdapter.getAllDevelopers();

                        for (DeveloperBean developerBean : developerBeanList) {
                            String users = " FirstName: " + developerBean.getDeveloper_firstname()+"\nLastname:"+developerBean.getDeveloper_lastname();
                            developerList.add(users);
                            Log.d("users: ", users);
                        }
                    }
                });

                alertDialogBuilder.setNegativeButton("No",new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,int id) {
                        dialog.cancel();
                        Toast.makeText(getApplicationContext(), "You chose cancel",
                                Toast.LENGTH_LONG).show();
                    }
                });

                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();

                return false;
            }
        });*/
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
}
